# lab05_homework

[![Build Status](https://travis-ci.org/Spardoks/lab05.svg?branch=master)](https://travis-ci.org/Spardoks/lab05_homework)

[![Coverage Status](https://coveralls.io/repos/github/Spardoks/lab05_homework/badge.svg)](https://coveralls.io/github/Spardoks/lab05_homework)

```
$ cmake -H. -B_build -DBUILD_TESTS=ON
$ cmake --build _build
$ cmake --build _build --target test

$ _build/check
$ cmake --build _build --target test -- ARGS=--verbose
```

[About old version of gmock, tutorial](https://youtu.be/jEaXP7XcuZg)
